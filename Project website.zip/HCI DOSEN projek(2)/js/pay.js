function validate(){
    // alert("Test")
    const caaar = document.getElementById("caaar").value;
    const card = document.getElementById("card-n").value;
    const ext = document.getElementById("ext").value;
    const cvc = document.getElementById("cvc").value;
    const amount = document.getElementById("amount").value;

    
    const eror1 = document.getElementById("eee1");
    const eror2 = document.getElementById("eee2");
    const eror3 = document.getElementById("eee3");
    const eror4 = document.getElementById("eee4");
    const eror5 = document.getElementById("eee5");

    var flek = true;

  if(caaar ==  ""){
      eror1.innerHTML = "Name Card Must filled";
      flek = false;
  }else{
      eror1.innerHTML = ""
  }
  if(card ==  ""){
    eror2.innerHTML = "Card Number Must filled";
    flek = false;
  }else if(isNaN(card)){
        eror2.innerHTML = "Card Number must be numeric"
        flek = false;
    
}else{
    eror2.innerHTML = ""
}
if(ext ==  ""){
    eror3.innerHTML = "Expired Date Must filled";
    flek = false;
}else if(isNaN(ext)){
    eror3.innerHTML = "Expired Date must be numeric"
    flek = false;
}else{
    eror3.innerHTML = ""
}
if(cvc ==  ""){
    eror4.innerHTML = "CVC Must filled";
    flek = false;
}else if(isNaN(cvc)){
    eror4.innerHTML = "CVC must be numeric"
    flek = false;
}else{
    eror4.innerHTML = ""
}
if(amount ==  ""){
    eror5.innerHTML = "Amount Must filled";
    flek = false;
}else if(isNaN(amount)){
    eror5.innerHTML = "Amount must be numeric"
    flek = false;
}else{
    eror5.innerHTML = ""
}
if(flek){
    alert("Donation Has Been Successfull");
}
    
}
