function validate(){
    // alert("Test")
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const tempat = document.getElementById("tempat").value;
    const address = document.getElementById("address").value;

    
    const eror1 = document.getElementById("eee1");
    const eror2 = document.getElementById("eee2");
    const eror3 = document.getElementById("eee3");
    const eror5 = document.getElementById("eee5");

    var flek = true;

    if(username == ""){
        eror1.innerHTML = "Username must be filled";
        flek = false;

    }else{
        eror1.innerHTML = "";
    }
    if(email == ''){
        eror2.innerHTML = "Email must be filled";
    }
    else if(email.indexOf("@") == -1){
        eror2.innerHTML = "Email must contains '@'";
        flek = false;
    }
    else if(email.split("@").length > 2){
        eror2.innerHTML = "Email must contains only one '@'";
        flek = false;
    }
    else if(!email.endsWith(".com")){
        eror2.innerHTML = "Email must ends with '.com'";
        flek = false;
    }else{
        eror2.innerHTML = "";
    }
    if(tempat == ''){
        eror3.innerHTML = "Address must be filled";
        flek = false;
    }else if(tempat.length > 101){
        eror3.innerHTML = "Address must be maximum 101 characters";
        flek = false;
    }  
      else{
            eror3.innerHTML = "";
        }
     if(address == ''){
        eror5.innerHTML = "Message must be filled";
        flek = false;
    }
    else if(address.length > 101){
        eror5.innerHTML = "Message must be maximum 101 characters";
        flek = false;
    }  
      else{
            eror5.innerHTML = "";
        }
        if(flek){
            alert("Message Has Been Sent")
        }
    }