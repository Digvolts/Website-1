const readmorebutton = document.querySelector('.btn');
const text = document.querySelector('.text');
const MoreText = document.querySelector('.MoreText');
readmorebutton.style.display="block";
readmorebutton
.addEventListener('click', (e)=>{
    TransitionEvent="0.5s"
    MoreText.classList.toggle('show-more')
    text.classList.toggle('show-more')
    if(readmorebutton.innerText == 'Read More'){
        readmorebutton.innerText == 'Read Less';
    }
    else{
        readmorebutton.innerText = 'Read More';
    }
})